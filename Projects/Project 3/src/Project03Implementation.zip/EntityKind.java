enum EntityKind
{
   ATLANTIS,
   OCTO_FULL,
   OCTO_NOT_FULL,
   OBSTACLE,
   FISH,
   CRAB,
   QUAKE,
   SGRASS
}
